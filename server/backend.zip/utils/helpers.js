import crypto from 'crypto'
import jwt from 'jsonwebtoken'
import { JWT_SECRET } from '../config/config.js'

// Encriptar contraseñas usando el algoritmo SHA256
export const encryptPassword = (password) => {
  return crypto.createHash('sha256').update(password).digest('hex')
}

// Compara dos contraseñas y devuelve un booleano
export const comparePasswords = (originalPass, passwordToCheck) => {
  return originalPass === passwordToCheck
}

// Generar JSON Web Token
export const generateToken = (username, role, firstName, lastName, email) => {
  return jwt.sign({ username, role, firstName, lastName, email }, JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN
  })
}
